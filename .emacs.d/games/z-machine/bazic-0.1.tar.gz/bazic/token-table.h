constant TOKEN_AND 255;
constant TOKEN_CLEAR 254;
constant TOKEN_CLS 253;
constant TOKEN_IF 252;
constant TOKEN_INPUT 251;
constant TOKEN_FOR 250;
constant TOKEN_GOTO 249;
constant TOKEN_LIST 248;
constant TOKEN_LOAD 247;
constant TOKEN_RND 246;
constant TOKEN_NEW 245;
constant TOKEN_NEXT 244;
constant TOKEN_OR 243;
constant TOKEN_PRINT 242;
constant TOKEN_QUIT 241;
constant TOKEN_REPEAT 240;
constant TOKEN_RUN 239;
constant TOKEN_SAVE 238;
constant TOKEN_SCRIPT 237;
constant TOKEN_STEP 236;
constant TOKEN_STOP 235;
constant TOKEN_THEN 234;
constant TOKEN_TO 233;
constant TOKEN_UNTIL 232;
constant TOKEN_VAL 231;
[ token_decode t;
switch(t) {
255: return "and";
236: return "step";
251: return "input";
243: return "or";
244: return "next";
237: return "script";
245: return "new";
242: return "print";
239: return "run";
233: return "to";
249: return "goto";
253: return "cls";
247: return "load";
235: return "stop";
254: return "clear";
238: return "save";
232: return "until";
240: return "repeat";
252: return "if";
231: return "val";
250: return "for";
246: return "rnd";
248: return "list";
234: return "then";
241: return "quit";
}
return 0;
];
[ token_encode p d;
if (
(p->0 == 'a') &&
(p->1 == 'n') &&
(p->2 == 'd') &&
 token_invalidchar(p->3)) { d->0 =255; return 3; }
if (
(p->0 == 's') &&
(p->1 == 't') &&
(p->2 == 'e') &&
(p->3 == 'p') &&
 token_invalidchar(p->4)) { d->0 =236; return 4; }
if (
(p->0 == 'i') &&
(p->1 == 'n') &&
(p->2 == 'p') &&
(p->3 == 'u') &&
(p->4 == 't') &&
 token_invalidchar(p->5)) { d->0 =251; return 5; }
if (
(p->0 == 'n') &&
(p->1 == 'e') &&
(p->2 == 'x') &&
(p->3 == 't') &&
 token_invalidchar(p->4)) { d->0 =244; return 4; }
if (
(p->0 == 'o') &&
(p->1 == 'r') &&
 token_invalidchar(p->2)) { d->0 =243; return 2; }
if (
(p->0 == 'n') &&
(p->1 == 'e') &&
(p->2 == 'w') &&
 token_invalidchar(p->3)) { d->0 =245; return 3; }
if (
(p->0 == 's') &&
(p->1 == 'c') &&
(p->2 == 'r') &&
(p->3 == 'i') &&
(p->4 == 'p') &&
(p->5 == 't') &&
 token_invalidchar(p->6)) { d->0 =237; return 6; }
if (
(p->0 == 'p') &&
(p->1 == 'r') &&
(p->2 == 'i') &&
(p->3 == 'n') &&
(p->4 == 't') &&
 token_invalidchar(p->5)) { d->0 =242; return 5; }
if (
(p->0 == 'r') &&
(p->1 == 'u') &&
(p->2 == 'n') &&
 token_invalidchar(p->3)) { d->0 =239; return 3; }
if (
(p->0 == 'c') &&
(p->1 == 'l') &&
(p->2 == 's') &&
 token_invalidchar(p->3)) { d->0 =253; return 3; }
if (
(p->0 == 'g') &&
(p->1 == 'o') &&
(p->2 == 't') &&
(p->3 == 'o') &&
 token_invalidchar(p->4)) { d->0 =249; return 4; }
if (
(p->0 == 't') &&
(p->1 == 'o') &&
 token_invalidchar(p->2)) { d->0 =233; return 2; }
if (
(p->0 == 'l') &&
(p->1 == 'o') &&
(p->2 == 'a') &&
(p->3 == 'd') &&
 token_invalidchar(p->4)) { d->0 =247; return 4; }
if (
(p->0 == 's') &&
(p->1 == 't') &&
(p->2 == 'o') &&
(p->3 == 'p') &&
 token_invalidchar(p->4)) { d->0 =235; return 4; }
if (
(p->0 == 'c') &&
(p->1 == 'l') &&
(p->2 == 'e') &&
(p->3 == 'a') &&
(p->4 == 'r') &&
 token_invalidchar(p->5)) { d->0 =254; return 5; }
if (
(p->0 == 's') &&
(p->1 == 'a') &&
(p->2 == 'v') &&
(p->3 == 'e') &&
 token_invalidchar(p->4)) { d->0 =238; return 4; }
if (
(p->0 == 'u') &&
(p->1 == 'n') &&
(p->2 == 't') &&
(p->3 == 'i') &&
(p->4 == 'l') &&
 token_invalidchar(p->5)) { d->0 =232; return 5; }
if (
(p->0 == 'r') &&
(p->1 == 'e') &&
(p->2 == 'p') &&
(p->3 == 'e') &&
(p->4 == 'a') &&
(p->5 == 't') &&
 token_invalidchar(p->6)) { d->0 =240; return 6; }
if (
(p->0 == 'i') &&
(p->1 == 'f') &&
 token_invalidchar(p->2)) { d->0 =252; return 2; }
if (
(p->0 == 'f') &&
(p->1 == 'o') &&
(p->2 == 'r') &&
 token_invalidchar(p->3)) { d->0 =250; return 3; }
if (
(p->0 == 'v') &&
(p->1 == 'a') &&
(p->2 == 'l') &&
 token_invalidchar(p->3)) { d->0 =231; return 3; }
if (
(p->0 == 'r') &&
(p->1 == 'n') &&
(p->2 == 'd') &&
 token_invalidchar(p->3)) { d->0 =246; return 3; }
if (
(p->0 == 'l') &&
(p->1 == 'i') &&
(p->2 == 's') &&
(p->3 == 't') &&
 token_invalidchar(p->4)) { d->0 =248; return 4; }
if (
(p->0 == 'q') &&
(p->1 == 'u') &&
(p->2 == 'i') &&
(p->3 == 't') &&
 token_invalidchar(p->4)) { d->0 =241; return 4; }
if (
(p->0 == 't') &&
(p->1 == 'h') &&
(p->2 == 'e') &&
(p->3 == 'n') &&
 token_invalidchar(p->4)) { d->0 =234; return 4; }
return 0;
];
